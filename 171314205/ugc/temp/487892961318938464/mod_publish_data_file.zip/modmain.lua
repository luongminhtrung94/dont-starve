TUNING.TENT_USES = GetModConfigData("uses")
TUNING.SIESTA_CANOPY_USES = GetModConfigData("uses2")

