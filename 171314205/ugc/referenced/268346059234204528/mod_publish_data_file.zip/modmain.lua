local RECIPETABS  = GLOBAL.RECIPETABS
local STRINGS     = GLOBAL.STRINGS
local Ingredient  = GLOBAL.Ingredient
local TECH        = GLOBAL.TECH

-- Twigs Recipe
local twigs_to_create = GetModConfigData('twigs_to_create') or 3

-- Log Recipe
local twigs_to_create_a_log = GetModConfigData('twigs_to_create_a_log') or 3

-- Recipe Description
STRINGS.RECIPE_DESC.TWIGS = 'Tiny logs, so useful!'
STRINGS.RECIPE_DESC.LOG   = 'A bundle of tiny logs, also useful!'


-- Twig Recipe
-- Takes 1 log.
local twigs_ingredients_table = { Ingredient("log", 1 ) }

-- Log Recipe
-- Takes 3 twigs by default.
local log_ingredients_table = { Ingredient("twigs", twigs_to_create_a_log ) }


--Recipe = Class(function(self, name, ingredients, tab, level, placer, min_spacing, nounlock, numtogive, builder_tag, atlas, image)
AddRecipe("twigs", twigs_ingredients_table, RECIPETABS.REFINE, TECH.SCIENCE_TWO, nil, nil, nil, twigs_to_create, nil, nil, nil)
AddRecipe("log", log_ingredients_table, RECIPETABS.REFINE, TECH.SCIENCE_TWO, nil, nil, nil, 1, nil, nil, nil)
